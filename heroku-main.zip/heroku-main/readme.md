'Aut vincere aut mori'
