import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from jinja2 import Environment, BaseLoader
import requests
from bs4 import BeautifulSoup
from email.utils import make_msgid
import telebot
from telebot import types
import os
from security import check_user, delete_user, add_user_db, get_users, change_email, get_email, get_integrations, \
    delete_integration, add_integration, add_template_db, \
    get_template_names, get_template_content, delete_template_db, get_users_to_delete, get_domains, del_domain, \
    add_domain_db

Token = "5401976912:AAHRgFkKnAr8zI7KtyXAEAh9CcdLjtVLa1I"

bot = telebot.TeleBot(Token, parse_mode=None)

default_dict = {}
emails = {}
email_to_change = {}

files = []
logg_chat = -619786498
users = {
    "admin56213": '4E6A2uRzc3',
    "admin12563": 'a6h!&z&HIP',
    "admin56328": 'm#X#NnXHc0',
    "admin96332": 'YpT*pw*PR4',
    "admin32336": 'Xmqq$p6D@j',
    "admin63369": 'Fdbg0HzR#2',
    "admin69331": 'sRDkKZ&tXz',
    "admin96558": '*eHW4eWY1!',
    "admin23669": 'AtLZ#2#hW%',
    "admin63277": 'ltV#w1@sQg',
    "admin36990": '&b^AF^0@ci'
}

get_activity_pass = "8R20N2qAHWYPDYkcXD7wT2ScIbX7ekNk4u6j9S4kpRzeMdkaGcFcv4qA3HJMjwJs"

logs = {}

default_rmk = types.ReplyKeyboardMarkup(resize_keyboard=True)
admin_rmk = types.ReplyKeyboardMarkup(resize_keyboard=True)
default_rmk.add(types.KeyboardButton("📧Отправить письмо📧"))
admin_rmk.add(types.KeyboardButton("📧Отправить письмо📧"))
admin_rmk.add(types.KeyboardButton("💾Добавить шаблон💾"))
admin_rmk.add(types.KeyboardButton("🗑Удалить шаблон🗑"))
admin_rmk.add(types.KeyboardButton("Добавить пользователя"))
admin_rmk.add(types.KeyboardButton("Удалить пользователя"))
admin_rmk.add(types.KeyboardButton("📧Сменить почту для отправок📧"))
admin_rmk.add(types.KeyboardButton("📧Отправить сообщение юзерам📧"))
admin_rmk.add(types.KeyboardButton("📧Создать интеграцию📧"))
admin_rmk.add(types.KeyboardButton("📧Удалить интеграцию📧"))
admin_rmk.add(types.KeyboardButton("Добавить домен"))
admin_rmk.add(types.KeyboardButton("Удалить домен"))


def geturl(url):
#     try:
#         r = requests.get('http://securiypay.com/yourls-api.php',
#                          params={'signature': 'a66abb5684', 'action': 'shorturl',
#                                  'url': url,
#                                  'keyword': '', 'format': 'json'})
#         short_url = r.json()['shorturl']
#         bot.send_message(logg_chat, f'Ссылка {url}, Кроп: {short_url}')
#         if short_url is not None:
#             return short_url
#         else:
#             return url
#     except Exception:
    return url



def send_email(title, url, send_to, template, integration=None):
    try:
        email_template = get_template_content(template)
        if email_template is not None:
            smtp_sender = get_email()

            url = geturl(url)

            SMTP_EMAIL = smtp_sender['name']
            SMTP_PASS = smtp_sender['pas']
            message = email_template.replace('{{ url }}', url)
            msg = MIMEMultipart("mixed")
            m = MIMEText(message, 'html')
            msg['Message-ID'] = make_msgid()
            msg['Subject'] = title
            msg['Content-Type'] = 'text/plain'
            msg['From'] = SMTP_EMAIL
            msg['To'] = send_to
            msg = msg
            port = 587  # For starttls
            smtp_server = "smtp-mail.outlook.com"
            sender_email = SMTP_EMAIL
            receiver_email = send_to
            password = SMTP_PASS
            msg.attach(m)

            context = ssl.create_default_context()
            with smtplib.SMTP(smtp_server, port) as server:
                server.ehlo()  # Can be omitted
                server.starttls(context=context)
                server.ehlo()  # Can be omitted
                server.login(sender_email, password)
                server.sendmail(sender_email, receiver_email, msg.as_string())
                server.close()

            if integration is not None:
                bot.send_message(logg_chat, f'Отправка с интеграции\nIntegration ID: {integration}')
    except Exception as e:
        bot.send_message(logg_chat, f'@trs_ts\nОшибка: {e}')


@bot.message_handler(commands=['statistics'])
def check_admin(message):
    bot.send_message(message.chat.id, "Введите пароль для получения статистики")
    bot.register_next_step_handler(message, send_statistics)


def send_statistics(message):
    if message.text == get_activity_pass:
        if len(logs) > 0:
            for user in logs:
                bot.send_message(message.chat.id, f'Логин: {logs[user]["login"]}\nИмя Изера: {logs[user]["tg_user"]}\n'
                                                  f'Отправок: {logs[user]["count"]}')
        else:
            bot.send_message(message.chat.id, 'На данный момент нет активных пользователей')
    else:
        bot.send_message(message.chat.id, 'Отказано в доступе')


@bot.message_handler(commands=['start'])
def send_welcome(message):
    rmk = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    rmk.add(types.KeyboardButton("☑Пользователь"), types.KeyboardButton("☑Админ"))
    bot.send_message(message.chat.id, "🔘Выбери доступ для входа:", reply_markup=rmk)
    bot.register_next_step_handler(message, user_name)


def user_name(message):
    if message.text == "☑Админ":
        bot.send_message(message.chat.id, "📝Введи логин")
        bot.register_next_step_handler(message, user_pass)
    elif message.text == "☑Пользователь":
        access = check_user(message.chat.id, message.from_user.username)
        if access:
            bot.send_message(message.chat.id, "☑Успешная авторизация", reply_markup=default_rmk)
        else:
            bot.send_message(message.chat.id, f"Доступ для вашего аккаунта ограничен\nОбратитесь к администратору\n"
                                              f"Ваш chat ID : {message.chat.id}\nПосле активации снова нажмите /start")
    else:
        send_welcome(message)


def user_pass(message):
    if message.text in users:
        logs[message.chat.id] = {}
        logs[message.chat.id]['login'] = message.text
        logs[message.chat.id]['tg_user'] = message.from_user.first_name
        logs[message.chat.id]['count'] = 0
        bot.send_message(message.chat.id, "📝Введи пароль")
        bot.register_next_step_handler(message, user_pass_check)
    else:
        bot.send_message(message.chat.id, "⚠Ошибка авторизации⚠")
        user_name(message)


def user_pass_check(message):
    if users[logs[message.chat.id]['login']] == message.text:
        default_dict[message.chat.id] = True
        bot.send_message(message.chat.id, "☑Успешная авторизация", reply_markup=admin_rmk)
    else:
        bot.send_message(message.chat.id, "⚠Ошибка авторизации⚠")
        user_name(message)


@bot.message_handler(content_types=['text'])
def check_text(message):
    menu = types.ReplyKeyboardMarkup(resize_keyboard=True)
    menu.add(types.KeyboardButton("Выход в меню"))
    access = check_user(message.chat.id, message.from_user.username)
    try:
        d = default_dict[message.chat.id]
    except KeyError:
        d = False
    if d:
        if message.text == "💾Добавить шаблон💾":
            bot.send_message(message.chat.id, "💾Отправьте шаблон для сохранения💾", reply_markup=menu)
        elif message.text == "🗑Удалить шаблон🗑":
            delete_template(message)
        elif message.text == "Удалить пользователя":
            curret_users = get_users_to_delete()
            users_rmk = types.ReplyKeyboardMarkup(resize_keyboard=True)
            back_rmk = types.InlineKeyboardMarkup()
            back_rmk.add(types.InlineKeyboardButton("Выход в меню", callback_data="menu"))
            for user in curret_users:
                users_rmk.add(types.KeyboardButton(user))
            bot.send_message(message.chat.id, "📝Выберите пользователя которого нужно удалить", reply_markup=users_rmk)
            bot.send_message(message.chat.id, "Для выхода в меню нажмите", reply_markup=back_rmk)
            bot.register_next_step_handler(message, del_user)
        elif message.text == "Добавить пользователя":
            bot.send_message(message.chat.id, "📝Введите Chat id пользователя которого нужно добавить",
                             reply_markup=menu)
            bot.register_next_step_handler(message, add_user)
        elif message.text == "📧Отправить письмо📧":
            bot.send_message(message.chat.id, "📝Введи почту получателя", reply_markup=menu)
            bot.register_next_step_handler(message, handle_email)
        elif message.text == "📧Сменить почту для отправок📧":
            bot.send_message(message.chat.id, "📝Введи новую почту", reply_markup=menu)
            bot.register_next_step_handler(message, handle_email_change)
        elif message.text == "📧Отправить сообщение юзерам📧":
            bot.send_message(message.chat.id, "📝Введи сообщение для отправки пользователям", reply_markup=menu)
            bot.register_next_step_handler(message, send_to_all)
        elif message.text == "📧Создать интеграцию📧":
            add_integration_admin(message)
        elif message.text == "📧Удалить интеграцию📧":
            bot.send_message(message.chat.id, '📝Введи id интеграции для удаления', reply_markup=menu)
            bot.register_next_step_handler(message, delete_integration)
        elif message.text == "Добавить домен":
            bot.send_message(message.chat.id, '📝Введи домен для добавления', reply_markup=menu)
            bot.register_next_step_handler(message, add_domain)
        elif message.text == "Удалить домен":
            back_rmk = types.InlineKeyboardMarkup()
            back_rmk.add(types.InlineKeyboardButton("Выход в меню", callback_data="menu"))
            curret_domains = get_domains()
            domains_rmk = types.ReplyKeyboardMarkup(resize_keyboard=True)
            for user in curret_domains:
                domains_rmk.add(types.KeyboardButton(user))
            domains_rmk.add(types.KeyboardButton("Выход в меню"))
            bot.send_message(message.chat.id, '📝Выберите домен для удаления', reply_markup=domains_rmk)
            bot.send_message(message.chat.id, "Для выхода в меню нажмите", reply_markup=back_rmk)
            bot.register_next_step_handler(message, delete_domain)
        elif message.text == "Выход в меню":
            go_to_menu(message)
        else:
            bot.send_message(message.chat.id, "❓Команда не найдена❓")
    elif access:
        if message.text == "📧Отправить письмо📧":
            bot.send_message(message.chat.id, "📝Введи почту получателя", reply_markup=menu)
            bot.register_next_step_handler(message, handle_email)
        elif message.text == "Выход в меню":
            go_to_menu(message)
        else:
            bot.send_message(message.chat.id, "❓Команда не найдена❓")
    else:
        bot.send_message(message.chat.id, f"Доступ для вашего аккаунта ограничен\nОбратитесь к администратору\n"
                                          f"Ваш chat ID : {message.chat.id}\n/start")


def add_user(message):
    try:
        if message.text == "Выход в меню":
            go_to_menu(message)
        elif default_dict[message.chat.id]:
            try:
                add_user_db(int(message.text))
                bot.send_message(message.chat.id, "Пользователь успешно добавлен")
                go_to_menu(message)
            except Exception as e:
                bot.send_message(message.chat.id, f"Ошибка при добавлении юзера\n{e}")
    except KeyError:
        bot.send_message(message.chat.id, "⚠Ошибка авторизации⚠ /start")


def del_user(message):
    try:
        if default_dict[message.chat.id]:
            if message.text == "Выход в меню":
                go_to_menu(message)
            try:
                chat_id = message.text.split('chat:')[1]
                try:
                    chat_id = int(chat_id)
                    delete_user(chat_id)
                    bot.send_message(message.chat.id, "Пользователь успешно удалён")
                    go_to_menu(message)
                except Exception:
                    go_to_menu(message)
            except Exception as e:
                bot.send_message(message.chat.id, f"Ошибка при удалении юзера\n{e}")
    except KeyError:
        bot.send_message(message.chat.id, "⚠Ошибка авторизации⚠ /start")


def delete_domain(message):
    try:
        if default_dict[message.chat.id]:
            if message.text == "Выход в меню":
                go_to_menu(message)
            try:
                try:
                    del_domain(message.text)
                    bot.send_message(message.chat.id, "Домен успешно удалён")
                    go_to_menu(message)
                except Exception:
                    go_to_menu(message)
            except Exception as e:
                bot.send_message(message.chat.id, f"Ошибка при удалении домена\n{e}")
    except KeyError:
        bot.send_message(message.chat.id, "⚠Ошибка авторизации⚠ /start")


def add_domain(message):
    try:
        if message.text == "Выход в меню":
            go_to_menu(message)
        elif default_dict[message.chat.id]:
            try:
                add_domain_db(message.text)
                bot.send_message(message.chat.id, "Домен успешно добавлен")
                go_to_menu(message)
            except Exception as e:
                bot.send_message(message.chat.id, f"Ошибка при добавлении домена\n{e}")
    except KeyError:
        bot.send_message(message.chat.id, "⚠Ошибка авторизации⚠ /start")


def add_integration_admin(message):
    try:
        if message.text == "Выход в меню":
            go_to_menu(message)
        elif default_dict[message.chat.id]:
            try:
                integration_id = add_integration()
                bot.send_message(message.chat.id, "Интеграция разрешена\nИнструкция по интеграции:\n"
                                                  "Для получения шаблонов используйте get"
                                                  " https://trs-mail.herokuapp.com/trs-mailer/templates"
                                                  " в headers запроса разместите ваш id интеграции как integration_id\n"
                                                  "Для отправки сообщения используйте post"
                                                  " https://trs-mail.herokuapp.com/trs-mailer/send-mail"
                                                  " в headers запроса разместите ваш id интеграции как integration_id"
                                                  " в body запроса разместите параметры:\n"
                                                  "url: ваша ссылка\ntitle: тема письма\nrecipient: почта получателя"
                                                  "\ntemplate: название шаблона TRS\n"
                                                  f"ID интеграции: {integration_id}")
                go_to_menu(message)
            except Exception as e:
                bot.send_message(message.chat.id, f"Ошибка при добавлении Интеграции\n{e}")
    except KeyError:
        bot.send_message(message.chat.id, "⚠Ошибка авторизации⚠ /start")


def del_integration(message):
    try:
        if default_dict[message.chat.id]:
            try:
                delete_integration(message.text)
                bot.send_message(message.chat.id, "Интеграция успешно удалена")
                go_to_menu(message)
            except Exception as e:
                bot.send_message(message.chat.id, f"Ошибка при удалении юзера\n{e}")
    except KeyError:
        bot.send_message(message.chat.id, "⚠Ошибка авторизации⚠ /start")


def go_to_menu(message):

    if isinstance(message, int):
        chat_id = message
    else:
        chat_id = message.chat.id
    try:
        if default_dict[chat_id]:
            bot.send_message(chat_id, 'Главное меню', reply_markup=admin_rmk)
    except KeyError:
        access = check_user(chat_id, message.from_user.username)
        if access:
            bot.send_message(chat_id, 'Главное меню', reply_markup=default_rmk)
        else:
            bot.send_message(chat_id, f"Доступ для вашего аккаунта ограничен\nОбратитесь к администратору\n"
                                              f"Ваш chat ID : {chat_id}")


def delete_template(message):
    try:
        if default_dict[message.chat.id]:
            files = get_template_names()
            if len(files) > 0:
                templates = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
                for file in files:
                    templates.add(types.KeyboardButton(file))
                templates.add(types.KeyboardButton('Выход в меню'))
                bot.send_message(message.chat.id, '🗂Выбор шаблона для удаления🗂', reply_markup=templates)
                bot.register_next_step_handler(message, delete_template_step)
            else:
                bot.send_message(message.chat.id, "⚠Шаблоны ещё не добавлены⚠")


    except KeyError:
        bot.send_message(message.chat.id, "⚠Ошибка авторизации⚠ /start")


def delete_template_step(message):
    files = get_template_names()
    if message.text in files:
        delete_template_db(message.text)
        bot.send_message(message.chat.id, "✅Шаблон успешно удалён✅", reply_markup=admin_rmk)
    elif message.text == "Выход в меню":
        go_to_menu(message)
    else:
        bot.send_message(message.chat.id, '⚠Шаблон не найден⚠\n⚠Выберите шаблон со списка⚠')
        delete_template(message)


def handle_email(message):
    if '@' in message.text:
        emails[message.chat.id] = {}
        emails[message.chat.id]['email'] = message.text
        nav = types.ReplyKeyboardMarkup(resize_keyboard=True)
        nav.add(types.KeyboardButton("Назад"))
        nav.add(types.KeyboardButton("Выход в меню"))
        bot.send_message(message.chat.id, "📝Введите свою ссылку", reply_markup=nav)
        bot.register_next_step_handler(message, handle_url)
    elif message.text == "Выход в меню":
        go_to_menu(message)
    else:
        bot.send_message(message.chat.id, "⚠Не корректный формат адреса⚠")
        message.text = "📧Отправить письмо📧"
        check_text(message)


def handle_email_change(message):
    if '@' in message.text:
        email_to_change[message.chat.id] = {}
        email_to_change[message.chat.id]['email'] = message.text
        nav = types.ReplyKeyboardMarkup(resize_keyboard=True)
        nav.add(types.KeyboardButton("Выход в меню"))
        bot.send_message(message.chat.id, "📝Введите пароль для почты", reply_markup=nav)
        bot.register_next_step_handler(message, handle_email_change_step)
    elif message.text == "Выход в меню":
        go_to_menu(message)
    else:
        bot.send_message(message.chat.id, "⚠Не корректный формат адреса⚠")
        message.text = "📧Сменить почту для отправок📧"
        check_text(message)


def handle_email_change_step(message):
    try:
        if message.text == "Выход в меню":
            go_to_menu(message)
        else:
            new_email = {
                'email': email_to_change[message.chat.id]['email'],
                'pas': message.text
            }
            change_email(new_email)
            bot.send_message(message.chat.id, "Почта отправитель успешно изменена", reply_markup=admin_rmk)
            bot.send_message(logg_chat, f"Почта отправитель изменена на {email_to_change[message.chat.id]['email']}")

    except Exception as e:
        bot.send_message(logg_chat, str(e))


def send_to_all(message):
    try:
        if message.text == "Выход в меню":
            go_to_menu(message)
        else:
            users = get_users()
            for user in users:
                try:
                    bot.send_message(user, message.text)
                except Exception as e:
                    print(f'Пользователь {user} удалил чат\nerror: {e}')
            bot.send_message(message.chat.id, 'Сообщение успешно доставлено пользователям', reply_markup=admin_rmk)
    except Exception as e:
        bot.send_message(message.chat.id, f"Ошибка отправки сообщения юзерам\n{e}")


def handle_url(message):
    if message.text == "Назад":
        message.text = "📧Отправить письмо📧"
        check_text(message)
    elif message.text == "Выход в меню":
        go_to_menu(message)
    else:
        try:
            if default_dict[message.chat.id]:
                emails[message.chat.id]['url'] = message.text
                bot.send_message(message.chat.id, "📝Введи тему письма")
                bot.register_next_step_handler(message, handle_title)
        except Exception:
            domains = get_domains()
            domain_access = False
            for domain in domains:
                if domain in message.text:
                    domain_access = True
                    break
            if domain_access:
                emails[message.chat.id]['url'] = message.text
                bot.send_message(message.chat.id, "📝Введи тему письма")
                bot.register_next_step_handler(message, handle_title)
            else:
                bot.send_message(message.chat.id,
                                 "⚠Домен не допущен⚠\n⚠Обратись в поддержку для одобрения вашего домена или введите другую ссылку⚠")
                message.text = emails[message.chat.id]['email']
                handle_email(message)


def handle_title(message):
    files = get_template_names()
    if message.text == "Назад":
        message.text = emails[message.chat.id]['email']
        handle_email(message)
    elif message.text == "Выход в меню":
        go_to_menu(message)
    elif len(files) > 0:
        files = get_template_names()
        templates = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        for file in files:
            templates.add(types.KeyboardButton(file))
        templates.add(types.KeyboardButton("Назад"))
        templates.add(types.KeyboardButton("Выход в меню"))
        bot.send_message(message.chat.id, '🗂Выбор шаблона🗂', reply_markup=templates)
        emails[message.chat.id]['title'] = message.text
        bot.register_next_step_handler(message, handle_templates)
    else:
        bot.send_message(message.chat.id, "⚠Шаблон не найден, загрузите шаблон⚠")
        message.text = "💾Добавить шаблон💾"
        check_text(message)


def handle_templates(message):
    files = get_template_names()
    if message.text == "Назад":
        message.text = emails[message.chat.id]['url']
        handle_url(message)
    elif message.text == "Выход в меню":
        go_to_menu(message)
    elif message.text in files:
        emails[message.chat.id]['template'] = message.text
        rmk = types.ReplyKeyboardMarkup(one_time_keyboard=True, resize_keyboard=True)
        rmk.add(types.KeyboardButton("✅ДА✅"), types.KeyboardButton("❌НЕТ❌"))
        bot.send_message(message.chat.id,
                         f"⚠️отправив ссылку через mailer вы соглашаетесь отдать 5% от общей суммы профита⚠️\n"
                         f"📥Получатель: {emails[message.chat.id]['email']}\n"
                         f"🔘Тема письма: {emails[message.chat.id]['title']}\n"
                         f"🔘Ссылка: {emails[message.chat.id]['url']}\n"
                         f"🔘Шаблон: {emails[message.chat.id]['template']}", reply_markup=rmk)
        bot.register_next_step_handler(message, handle_answer)
    else:
        bot.send_message(message.chat.id, '⚠Шаблон не найден⚠')
        message.text = emails[message.chat.id]['title']
        handle_title(message)


def handle_answer(message):
    if message.text == "Назад":
        message.text = emails[message.chat.id]['title']
        handle_title(message)
    elif message.text == "Выход в меню":
        go_to_menu(message)
    elif message.text == "✅ДА✅":
        try:
            bot.send_message(message.chat.id, "⏳Идет процесс отправки⌛")
            send_email(title=emails[message.chat.id]['title'], url=emails[message.chat.id]['url'],
                       send_to=emails[message.chat.id]['email'], template=emails[message.chat.id]['template'], )
            bot.send_message(message.chat.id, "☑Письмо доставлено☑", reply_markup=default_rmk)
            bot.send_message(logg_chat, f"📥Получатель: {emails[message.chat.id]['email']}\n"
                                        f"🔘Тема письма: {emails[message.chat.id]['title']}\n"
                                        f"🔘Ссылка: {emails[message.chat.id]['url']}\n"
                                        f"🔘Шаблон: {emails[message.chat.id]['template']}\n"
                                        f"🔘Пользователь: {message.from_user.first_name}\n"
                                        f"TG username: {message.from_user.username}")
        except Exception as e:
            bot.send_message(logg_chat, f"Ошибка отправки {e}")
    elif message.text == "❌НЕТ❌":
        bot.send_message(message.chat.id, "⚠Отмена отправки, используйте клавиатуру для навигации⚠",
                         reply_markup=default_rmk)


@bot.message_handler(content_types=['document'])
def handle_docs(message):
    try:
        if default_dict[message.chat.id]:
            chat_id = message.chat.id

            file_info = bot.get_file(message.document.file_id)
            downloaded_file = bot.download_file(file_info.file_path)
            src = './templates/' + message.document.file_name
            with open(src, 'wb') as new_file:
                new_file.write(downloaded_file)
            file = open(src, encoding="utf8")
            content = file.read()
            add_template_db(content=content, template_name=message.document.file_name)
            files.clear()
            bot.send_message(chat_id, "☑Шаблон успешно загружен☑", reply_markup=default_rmk)
    except KeyError:
        bot.send_message(message.chat.id, "⚠Ошибка авторизации⚠ /start")


@bot.callback_query_handler(func=lambda call: True)
def callback_query(call):
    if call.data == "menu":
        go_to_menu(call.message.chat.id)


bot.infinity_polling()
