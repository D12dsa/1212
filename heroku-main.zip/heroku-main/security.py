import pymongo
import uuid

def check_user(chat_id, user_teg):
    chat_id = int(chat_id)
    active_users = []
    checked = []
    client = pymongo.MongoClient("mongodb+srv://RootUser:Sansamourdd1@cluster0.a2t8t.mongodb.net/trsData?retryWrites=true&w=majority")
    db = client["trsData"]
    col = db["users"]
    db_update = []
    users = col.find()
    for data in users:
        active_users = data['users']
        for user in active_users:
            if isinstance(user, dict):
                checked.append(user["id"])
                db_update.append(user)
            elif user != chat_id:
                db_update.append(user)
            else:
                checked.append(user)
                db_update.append({'id': user, 'tag': user_teg})
    col.drop()
    col = db["users"]
    col.insert_one({"users": db_update})

    return chat_id in checked


def get_users():
    client = pymongo.MongoClient(
        "mongodb+srv://RootUser:Sansamourdd1@cluster0.a2t8t.mongodb.net/trsData?retryWrites=true&w=majority")
    db = client["trsData"]
    col = db["users"]
    users = col.find()
    sorted_users = []
    for data in users:
        active_users = data['users']
        for user in active_users:
            if isinstance(user, dict):
                sorted_users.append(user['id'])
            else:
                sorted_users.append(user)
    return sorted_users


def get_users_to_delete():
    client = pymongo.MongoClient(
        "mongodb+srv://RootUser:Sansamourdd1@cluster0.a2t8t.mongodb.net/trsData?retryWrites=true&w=majority")
    db = client["trsData"]
    col = db["users"]
    users = col.find()
    sorted_users = []
    for data in users:
        active_users = data['users']
        for user in active_users:
            if isinstance(user, dict):
                sorted_users.append(f'{user["tag"]} chat:{user["id"]}')
            else:
                sorted_users.append(f'chat:{user}')
    return sorted_users


def delete_user(chat_id):
    active_users = []
    client = pymongo.MongoClient(
        "mongodb+srv://RootUser:Sansamourdd1@cluster0.a2t8t.mongodb.net/trsData?retryWrites=true&w=majority")
    db = client["trsData"]
    col = db["users"]
    users = col.find()
    for data in users:
        active_users = data['users']
    i = 0
    new_users = []
    while i < len(active_users):
        if active_users[i] != chat_id:
            new_users.append(active_users[i])
        i += 1
    col.drop()
    col = db["users"]
    col.insert_one({"users": new_users})


def add_user_db(chat_id):
    active_users = []
    client = pymongo.MongoClient(
        "mongodb+srv://RootUser:Sansamourdd1@cluster0.a2t8t.mongodb.net/trsData?retryWrites=true&w=majority")
    db = client["trsData"]
    col = db["users"]
    users = col.find()
    for data in users:
        active_users = data['users']
    if chat_id not in active_users:
        active_users.append(chat_id)
    col.drop()
    col = db["users"]
    col.insert_one({"users": active_users})


def change_email(new_email):
    client = pymongo.MongoClient(
        "mongodb+srv://RootUser:Sansamourdd1@cluster0.a2t8t.mongodb.net/trsEmails?retryWrites=true&w=majority")
    db = client["trsData"]
    col = db["emails"]
    col.drop()
    col = db["emails"]
    col.insert_one({"email": {
        'name': new_email['email'],
        'pas': new_email['pas']}})


def get_email():
    email_user = None
    client = pymongo.MongoClient(
        "mongodb+srv://RootUser:Sansamourdd1@cluster0.a2t8t.mongodb.net/trsData?retryWrites=true&w=majority")
    db = client["trsData"]
    col = db["emails"]
    users = col.find()
    for data in users:
        email_user = data['email']
    return email_user


def get_integrations():
    active_integrations = []
    client = pymongo.MongoClient(
        "mongodb+srv://RootUser:Sansamourdd1@cluster0.a2t8t.mongodb.net/trsData?retryWrites=true&w=majority")
    db = client["trsData"]
    col = db["integrations"]
    users = col.find()
    for data in users:
        active_integrations = data['integrations']
    return active_integrations


def delete_integration(integration_id):
    active_users = []
    client = pymongo.MongoClient(
        "mongodb+srv://RootUser:Sansamourdd1@cluster0.a2t8t.mongodb.net/trsData?retryWrites=true&w=majority")
    db = client["trsData"]
    col = db["integrations"]
    users = col.find()
    for data in users:
        active_users = data['integrations']
    i = 0
    new_users = []
    while i < len(active_users):
        if active_users[i] != integration_id:
            new_users.append(active_users[i])
        i += 1
    col.drop()
    col = db["integrations"]
    col.insert_one({"integrations": new_users})


def add_integration():
    active_users = []
    client = pymongo.MongoClient(
        "mongodb+srv://RootUser:Sansamourdd1@cluster0.a2t8t.mongodb.net/trsData?retryWrites=true&w=majority")
    db = client["trsData"]
    col = db["integrations"]
    users = col.find()
    integration_id = uuid.uuid4().hex
    for data in users:
        active_users = data['integrations']
    if integration_id not in active_users:
        active_users.append(integration_id)
    col.drop()
    col = db["integrations"]
    col.insert_one({"integrations": active_users})
    return integration_id


def add_template_db(template_name, content):
    active_templates = []
    names = []
    client = pymongo.MongoClient(
        "mongodb+srv://RootUser:Sansamourdd1@cluster0.a2t8t.mongodb.net/trsData?retryWrites=true&w=majority")
    db = client["trsData"]
    col = db["templates"]
    users = col.find()
    for data in users:
        active_templates = data['templates']
    for template in active_templates:
        names.append(template['name'])
    if template_name not in names:
        active_templates.append({
            'name': template_name,
            'content': content
        })
    col.drop()
    col = db["templates"]
    col.insert_one({"templates": active_templates})


def get_template_names():
    active_templates = []
    names = []
    client = pymongo.MongoClient(
        "mongodb+srv://RootUser:Sansamourdd1@cluster0.a2t8t.mongodb.net/trsData?retryWrites=true&w=majority")
    db = client["trsData"]
    col = db["templates"]
    users = col.find()
    for data in users:
        active_templates = data['templates']
    for template in active_templates:
        names.append(template['name'])
    return names


def get_template_content(template_name):
    active_templates = []
    client = pymongo.MongoClient(
        "mongodb+srv://RootUser:Sansamourdd1@cluster0.a2t8t.mongodb.net/trsData?retryWrites=true&w=majority")
    db = client["trsData"]
    col = db["templates"]
    users = col.find()
    for data in users:
        active_templates = data['templates']
    for template in active_templates:
        if template['name'] == template_name:
            return template['content']
    else:
        return None


def delete_template_db(template_name):
    active_templates = []
    new_temp = []
    client = pymongo.MongoClient(
        "mongodb+srv://RootUser:Sansamourdd1@cluster0.a2t8t.mongodb.net/trsData?retryWrites=true&w=majority")
    db = client["trsData"]
    col = db["templates"]
    users = col.find()
    for data in users:
        active_templates = data['templates']
    for template in active_templates:
        if template['name'] != template_name:
            new_temp.append(template)
    col.drop()
    col = db["templates"]
    col.insert_one({"templates": new_temp})


def get_domains():
    active_users = []
    client = pymongo.MongoClient(
        "mongodb+srv://RootUser:Sansamourdd1@cluster0.a2t8t.mongodb.net/trsData?retryWrites=true&w=majority")
    db = client["trsData"]
    col = db["domains"]
    users = col.find()
    for data in users:
        active_users = data['domains']
    return active_users


def del_domain(domain):
    active_users = []
    client = pymongo.MongoClient(
        "mongodb+srv://RootUser:Sansamourdd1@cluster0.a2t8t.mongodb.net/trsData?retryWrites=true&w=majority")
    db = client["trsData"]
    col = db["domains"]
    users = col.find()
    for data in users:
        active_users = data['domains']
    i = 0
    new_users = []
    while i < len(active_users):
        if active_users[i] != domain:
            new_users.append(active_users[i])
        i += 1
    col.drop()
    col = db["domains"]
    col.insert_one({"domains": new_users})


def add_domain_db(chat_id):
    active_users = []
    client = pymongo.MongoClient(
        "mongodb+srv://RootUser:Sansamourdd1@cluster0.a2t8t.mongodb.net/trsData?retryWrites=true&w=majority")
    db = client["trsData"]
    col = db["domains"]
    users = col.find()
    for data in users:
        active_users = data['domains']
    if chat_id not in active_users:
        active_users.append(chat_id)
    col.drop()
    col = db["domains"]
    col.insert_one({"domains": active_users})
